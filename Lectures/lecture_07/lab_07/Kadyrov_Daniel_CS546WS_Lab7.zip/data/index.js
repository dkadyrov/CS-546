const animalData = require("./animals");
const postData = require("./posts");
const likeData = require("./likes")

module.exports = {
  animals: animalData,
  posts: postData,
  likes: likeData
};